# Paris Bulwark (working title): design brief

**One sentence:** A solo build-and-defend mashup where the player, in Assassin's Creed Unity's Paris, uses Fortnite's building pieces and weapons to hold a landmark against Parisian mobs.

## Agreed design
- **Host (role "primary"):** Assassin's Creed Unity, an installed game outside the catalog (a `custom-` slug from `search_games`).
- **Companion (role "companion"):** Fortnite. Never launched and never modded. Its building pieces and weapons are read from the player's own install via `{game:fortnite}`. Nothing from Fortnite is copied or uploaded. `recipe.together` is not needed.
- **Players:** solo only for the first version. No `recipe.multiplayer` block.
- **First minute:** the player starts defending a landmark (Notre-Dame courtyard first, a rooftop later) from wave one.
- **First playable must have:** placing and editing Fortnite building pieces, and a few Fortnite weapons to find and use.
- **Not required for v1:** escalating waves, win/lose, outfits and emotes, music and sound. Wave 1 is a minimal test wave so building and weapons have targets. This is a design assumption; change it if you want something different.

## Files
`games`, `hooks`, `resources`, `building_pieces`, `weapons`, `enemies`, `waves`, `arenas` and `systems` (`.json`) are the sheets. They are the source of truth: change a sheet before changing code. `PREFLIGHT.md` lists every unfilled first-version cell (91 at generation time, 0 broken references). Build only when it reaches zero.

## Open risks to settle first
These have not been verified, because no game folders or network were available when this was written.
1. **ACU has no Melty loader.** The route has to be found from its files: a proxy DLL or hook, reading memory, and community tools for its archives. Placing new meshes with collision and spawning NPCs are the hard parts.
2. **Fortnite content is packed in encrypted Unreal archives.** Reading its meshes and weapon data at runtime from the player's install may need keys that change with game updates. Check this before writing code.
3. If either risk blocks the design, explain it to the user and get agreement before changing anything. Do not swap games or substitute look-alike content.

## Build agent order
1. Connect to Melty, then call `list_my_mods`, `search_mashups`, `mashup_info` on the closest hit, and `game_info` for both games.
2. Set up universal-modder and identify the ACU engine and hook route from the installed files.
3. Fill the sheets, run the preflight, build, test in the running game and capture a real screenshot.
4. Run `inspect_package`, `validate_recipe` and `one_click_check`, then `create_mod`, upload, `submit_release` and `add_screenshot`.
5. Ask the user before calling `publish`.
