# Preflight (generated)

## games: 3 unfilled cells in first-version rows

acu.loaderRoute, acu.versionTested, fortnite.versionTested

## hooks: 18 unfilled cells in first-version rows

H_input.route, H_input.verified, H_camera.route, H_camera.verified, H_player.route, H_player.verified, H_spawn_prop.route, H_spawn_prop.verified, H_spawn_npc.route, H_spawn_npc.verified, H_damage.route, H_damage.verified, H_hud.route, H_hud.verified, H_region.route, H_region.verified, H_fn_assets.route, H_fn_assets.verified

## resources: 12 unfilled cells in first-version rows

wood.fortniteAsset, wood.startingAmount, wood.harvestSource, wood.amountPerHit, stone.fortniteAsset, stone.startingAmount, stone.harvestSource, stone.amountPerHit, metal.fortniteAsset, metal.startingAmount, metal.harvestSource, metal.amountPerHit

## building_pieces: 24 unfilled cells in first-version rows

wall.fortniteAsset, wall.gridSize, wall.costMaterial, wall.costAmount, wall.health, wall.placeKey, floor.fortniteAsset, floor.gridSize, floor.costMaterial, floor.costAmount, floor.health, floor.placeKey, ramp.fortniteAsset, ramp.gridSize, ramp.costMaterial, ramp.costAmount, ramp.health, ramp.placeKey, roof.fortniteAsset, roof.gridSize, roof.costMaterial, roof.costAmount, roof.health, roof.placeKey

## weapons: 21 unfilled cells in first-version rows

weapon_shotgun.fortniteAsset, weapon_shotgun.damage, weapon_shotgun.clipSize, weapon_shotgun.fireRate, weapon_shotgun.reloadTime, weapon_shotgun.ammoType, weapon_shotgun.sound, weapon_rifle.fortniteAsset, weapon_rifle.damage, weapon_rifle.clipSize, weapon_rifle.fireRate, weapon_rifle.reloadTime, weapon_rifle.ammoType, weapon_rifle.sound, weapon_pistol.fortniteAsset, weapon_pistol.damage, weapon_pistol.clipSize, weapon_pistol.fireRate, weapon_pistol.reloadTime, weapon_pistol.ammoType, weapon_pistol.sound

## enemies: 4 unfilled cells in first-version rows

mob_revolutionary.acuNpcType, mob_revolutionary.health, mob_revolutionary.speed, mob_revolutionary.attackDamage

## waves: 2 unfilled cells in first-version rows

w1_a.count, w1_a.spawnInterval

## arenas: 4 unfilled cells in first-version rows

arena_notre_dame.acuRegion, arena_notre_dame.playerSpawn, arena_notre_dame.defendTarget, arena_notre_dame.enemySpawnPoints

## systems: 3 unfilled cells in first-version rows

build_mode.verified, edit_mode.verified, wave_director.verified


## Unresolved references: 0

none


**Total unfilled first-version cells: 91.** Build only when this is zero.
